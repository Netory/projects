<!DOCTYPE html>
<html lang="fr">
  <head>
      <title>Ma page</title>
      <meta charset="utf-8">
	  <link rel="stylesheet"  href="vue/style/style.css" />
	  
  </head>

  <body>
    <form id="monForm1" action="forum.php" method="post">
      <p>Ici le directeur</p>
      <p><input type="submit" value="Deconnexion" name="deconnexion"><p>

    </form>
  </body>
</html>