<?php
require_once('modele/modele.php') ;
require_once('vue/vue.php') ;   

function CtlLogin(){
    AfficheLogin(); // appel de la vue qui va exploiter $discussion et afficher // son contenu
}
function CtlConnexion($login,$mdp){
    $Check=checkUser($login,$mdp);
    if ($Check && isset($Check->categorie)) {
        if ($Check->categorie == 'directeur') {
            AfficheDirecteur();
        } elseif ($Check->categorie == 'conseiller') {
            AfficheConseiller();
        } elseif ($Check->categorie == 'agent') {
            AfficheAgent();
        }
    } else {
        CtlLogin();
    }
}

function CtlAdd($nom, $login, $mdp, $categorie){
    AddEmploye($nom, $login, $mdp, $categorie);
}
function CtlErreur($erreur){
    afficherErreur($erreur);
}
function CtlModification() {
    $employes=GetEmployePourDirecteur();
    afficheModifEmploye($employes);
}
function CtlsupprimerEmploye($unemp){
    supprimerEmploye($unemp);
}

function CtlModifie(){
    if(isset($_POST['id']) && isset($_POST['login']) && isset($_POST['mdp'])){
        $list_emp= $_POST['id'];
        $list_login=$_POST['login'];
        $list_mdp=$_POST['mdp'];
            foreach ($list_emp as $index => $idemp) {
                $login = $list_login[$index];
                $mdp = $list_mdp[$index];
                UpdateEmploye($idemp, $login, $mdp);

        }
        CtlModification();


    }
 
}

function CtlsupprimerContrat($contrat){
    $typecontrat="Souscription $contrat";
    supprimermotif($typecontrat);
    supprimerContrat($contrat);
}
function Ctlmodi_contrat(){
    $contrat=GetListeContrat();
    $motif=GetMotif();
    AfficheModiContrat($contrat,$motif);
}
function Ctlmodi_compte(){
    $compte=GetListeCompte();
    $motifs=GetMotif();
    AfficheModiCompte($compte,$motifs);

}
function CtlsupprimerCompte($compte){
    $typecompte="Ouverture $compte";
    supprimermotif($typecompte);
    supprimerCompte($compte);
}
function Ctlajoutcompte($nomcompte,$pieces){
    ajoutcompte($nomcompte);
    $typecompte="Ouverture $nomcompte";
    ajoutmotif($typecompte,$pieces);
    Ctlmodi_compte();
}
function Ctlajoutcontrat($nomcontrat,$pieces){
    ajoutcontrat($nomcontrat);
    $typecontrat="Souscription $nomcontrat";
    ajoutmotif($typecontrat,$pieces);
    Ctlmodi_contrat();
}
function CtlModifPieces($listeid,$listePieces){
    foreach ($listeid as $index => $id) {
        $pieces = $listePieces[$index];
        UpdateMotif($pieces,$id);
    }
    Ctlmodi_compte();
}