<?php
require_once('controleur/controleur.php'); // charge les méthodes du contrôleur
require_once('vue/vue.php');

    if (isset($_POST['connexion'])){ // si on a cliqué sur Envoyer
        $login=$_POST['login'];
        $mdp=$_POST['mdp'];
        CtlConnexion($login,$mdp);
    }
    elseif(isset($_POST['deconnexion'])){
        CtlLogin();
    }
    elseif(isset($_POST['modification'])){
        CtlModification();

    }
    elseif(isset($_POST['modifie'])){
        CtlModifie();
    }
    elseif(isset($_POST['ajout_agent'])){
        $nom=$_POST['nom_agent'];
        $login=$_POST['login_agent'];
        $mdp=$_POST['mdp_agent'];
        $categorie='Agent';
        CtlAdd($nom,$login,$mdp,$categorie);
        CtlModification();
        
    }
    elseif(isset($_POST['ajout_conseiller'])){
        $nom=$_POST['nom_conseiller'];
        $login=$_POST['login_conseiller'];
        $mdp=$_POST['mdp_conseiller'];
        $categorie='Conseiller';
        CtlAdd($nom,$login,$mdp,$categorie);
        CtlModification();
        
    }
    elseif(isset($_POST['supprimerEmp'])){
            $EmployerASupprimer = $_POST['supprimer'];
                foreach($EmployerASupprimer as $unemp){
                    CtlsupprimerEmploye($unemp);
                }
            CtlModification();
    }
    elseif(isset($_POST['Page_Directeur'])){
        AfficheDirecteur();
    }
    elseif(isset($_POST['Deconnexion'])){
        CtlLogin();
    }
    elseif(isset($_POST['modi_contrat'])){
        Ctlmodi_contrat();
    }
    elseif(isset($_POST['modi_compte'])){
        Ctlmodi_compte();
    }
    elseif(isset($_POST['supprimerContrat'])){
        $ContratASupprimer = $_POST['supprimer'];
            foreach($ContratASupprimer as $uncontrat){
                CtlsupprimerContrat($uncontrat);
            }
        Ctlmodi_contrat();
    }
    elseif(isset($_POST['supprimerCompte'])){
        $compteASupprimer = $_POST['supprimer'];
            foreach($compteASupprimer as $uncompte){
                CtlsupprimerCompte($uncompte);
            }
        Ctlmodi_compte();
    }
    elseif(isset($_POST['ajoutcompte'])){
        $nomcompte= $_POST['TypeCompte'];
        $pieces=$_POST['PiecesDemande'];
        Ctlajoutcompte($nomcompte,$pieces);
    }
    elseif(isset($_POST['ajoutcontrat'])){
        $nomcontrat= $_POST['Typecontrat'];
        $pieces=$_POST['Pieces'];
        Ctlajoutcontrat($nomcontrat,$pieces);
    }
    elseif(isset($_POST['ModifPieces'])){
        $listeid=$_POST['idPieces'];
        $listePieces=$_POST['Pieces'];
        CtlModifPieces($listeid,$listePieces);
    }







    else CtlLogin(); // on vient d'arriver sur la page et on appelle le contrôleur qui gère

