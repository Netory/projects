<?php
    define("SERVEUR","localhost");
    define("USER","root");
    define("PASSWORD","");
    define("BDD","banque_sprint_2");