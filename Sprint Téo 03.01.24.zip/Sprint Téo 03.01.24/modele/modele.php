<?php
require_once("connect.php");
function getConnect(){
    $connexion=new PDO('mysql:host='.SERVEUR.';dbname='.BDD,USER,PASSWORD);
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $connexion->query('SET NAMES UTF8');
    return $connexion;
}
function checkUser($login,$mdp){
    $connexion=getConnect();
    $requete="SELECT categorie from employe where login='$login' and mdp='$mdp'";
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $categorie=$resultat->fetch();
    $resultat->closeCursor();
    return $categorie;
}
function GetEmployePourDirecteur(){
    $connexion=getConnect();
    $requete="SELECT numEmploye,nom,login,mdp FROM employe WHERE categorie='Agent' or categorie='conseiller'";
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $liste=$resultat->fetchall();
    return $liste;
}
function UpdateEmploye($id, $login, $mdp, ){
        $connexion = getConnect();
        $requete = "UPDATE employe SET login = '$login', mdp = '$mdp' WHERE numEmploye = $id";
        $resultat=$connexion->query($requete);
        $resultat->closeCursor();
}
function AddEmploye($nom, $login, $mdp, $categorie){
        $connexion = getConnect();
        $requete = "INSERT INTO employe (nom, login, mdp, categorie) VALUES ('$nom', '$login', '$mdp', '$categorie')";
        $resultat=$connexion->query($requete);
        $resultat->closeCursor();
}
function supprimerEmploye($id){
    $connexion=getConnect();
    $requete="delete from employe where numEmploye=($id)";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function GetListeContrat(){
    $connexion=getConnect();
    $requete="Select * from contrat";
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $contrat=$resultat->fetchall();
    return $contrat;

}
function GetListeCompte(){
    $connexion=getConnect();
    $requete="Select * from compte";
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $compte=$resultat->fetchall();
    return $compte;

}
function supprimerContrat($contrat){
    $connexion=getConnect();
    $requete="DELETE from contrat where nomContrat= '$contrat' ";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function supprimerCompte($compte){
    $connexion=getConnect();
    $requete="DELETE from compte where nomCompte= '$compte' ";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function ajoutcompte($typecompte){
    $connexion=getConnect();
    $requete="INSERT INTO compte (nomCompte) VALUES ('$typecompte')";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function ajoutmotif($type,$pieces){
    $connexion=getConnect();
    $requete="INSERT INTO motif (libelleMotif, listePieces) Values ('$type', '$pieces')";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function ajoutcontrat($typecontrat){
    $connexion=getConnect();
    $requete="INSERT INTO contrat (nomContrat) VALUES ('$typecontrat')";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function supprimermotif($type){
    $connexion=getConnect();
    $requete="DELETE from motif where libelleMotif= '$type' ";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}
function getMotif(){
    $connexion=getConnect();
    $requete="Select * from motif";
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $motifs=$resultat->fetchall();
    return $motifs;

}
function UpdateMotif($liste,$id){
    $connexion=getConnect();
    $requete="UPDATE motif SET listePieces='$liste' WHERE idmotif=$id";
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}

    
    

   