<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Ma page</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="vue/style/style.css" />
</head>

<body>
    <header>
        <h1>Ici le directeur</h1>
    </header>
    <section class="container">
        <form id="monForm1" action="forum.php" method="post">
          <p><input type="submit" value="Deconnexion" name="Deconnexion"></p>
          <p><input type="submit" value="Modification" name="modification"></p>
          <p><input type="submit" value="Modifier Contrat" name="modi_contrat"></p>
          <p><input type="submit" value="Modifier Compte" name="modi_compte"></p>

        </form>
    </section>

</body>

</html>