<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Ma page</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="vue/style/style.css" />
</head>

<body>
    <header>
        <h1>Ici page modif agent</h1>
    </header>

    <nav>
      <form id="monForm1" action="forum.php" method="post">
        <p><input type="submit" value="Retour" name="Page_Directeur"><input type="submit" value="Deconnexion" name="Deconnexion"><p>
      </form>
    </nav>

    <section class="container">
      <fieldset class="fieldset">
        <legend>Modification des logins et mots de passe</legend>
        <form id="monForm2" action="forum.php" method="post">
            <?php
            foreach ($employe as $ligne) {
                echo '<p>' . $ligne->nom . '<input type="text" name="id[]" value="' . $ligne->numEmploye . '" readonly="readonly" /></p>';
                echo '<p><input type="text" name="login[]" value="' . $ligne->login . '" /><input type="text" name="mdp[]" value="' . $ligne->mdp . '" /></p>';
                echo '<input type="checkbox" name="supprimer[]" value="' . $ligne->numEmploye . '"/>';
            }
            ?>
            <p><input type="submit" value="Modifier" name="modifie" /></p>
            <p><input type="submit" value="Supprimer" name="supprimerEmp" /></p>
        </form>
      </fieldset>

      <fieldset class="fieldset">
          <legend>Ajouter un Agent d'accueil</legend>
          <form id="monForm3" action="forum.php" method="post">
              <p><input type="text" name="nom_agent" value="Nom" /><input type="text" name="login_agent" value="Login" /><input type="text" name="mdp_agent" value="Mdp" /></p>
              <p><input type="submit" name="ajout_agent" value="Ajout Agent" /></p>
          </form>
      </fieldset>

      <fieldset class="fieldset">
          <legend>Ajouter un Conseiller</legend>
          <form id="monForm4" action="forum.php" method="post">
              <p><input type="text" name="nom_conseiller" value="Nom" /><input type="text" name="login_conseiller" value="Login" /><input type="text" name="mdp_conseiller" value="Mdp" /></p>
              <p><input type="submit" name="ajout_conseiller" value="Ajout Conseiller" /></p>
          </form>
      </fieldset>
    </section>

    
</body>

</html>