<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Ma page</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="vue/style/style.css" />
</head>

<body>
    <header>
        <h1>Login</h1>
    </header>

    <section class="container">
        <form id="monForm1" action="forum.php" method="post">
            <p><label> Login : </label><input type="text" name="login" /></p>
            <p><label> Mot de passe : </label><input type="password" name="mdp" /></p>
            <p> <input type="submit" value="Connexion" name="connexion" /> </p>
        </form>
    </section>

    <footer class="footer">
        <!-- Contenu du pied de page ici -->
    </footer>
</body>

</html>