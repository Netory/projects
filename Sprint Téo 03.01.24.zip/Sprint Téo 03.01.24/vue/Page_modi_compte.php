<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Ma page</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="vue/style/style.css" />
</head>

<body>
    <header>
        <h1>Ici page modif compte</h1>
    </header>

    <nav>
      <form id="monForm1" action="forum.php" method="post">
        <p><input type="submit" value="Retour" name="Page_Directeur"><input type="submit" value="Deconnexion" name="Deconnexion"><p>
      </form>
    </nav>

    <section class="container">
        <form id="monForm2" action="forum.php" method="post">
            <?php
            foreach ($compte as $ligne) {
                echo '<p>' . $ligne->nomCompte . '<input type="checkbox" name="supprimer[]" value="' . $ligne->nomCompte . '"/></p>';
                foreach ($motifs as $libelle) {
                    if ($libelle->libelleMotif == 'Ouverture ' . $ligne->nomCompte) {
                        echo '<p><input type="text" name="Pieces[]" value="' . $libelle->listePieces . '" /><input type="hidden" name="idPieces[]" value="' . $libelle->idMotif . '"/></p>';
                        break;
                    }
                }
            }
            ?>
            <p><input type="submit" value="Modifier" name="ModifPieces" /></p>
            <p><input type="submit" value="Supprimer" name="supprimerCompte" /></p>
            <p><input type="text" value="Type de Compte" name="TypeCompte" /><input type="text" value="Pieces demandé" name="PiecesDemande" /></p>
            <p><input type="submit" value="Soumettre" name="ajoutcompte" /></p>
        </form>
    </section>

    <footer class="footer">
        <!-- Contenu du pied de page ici -->
    </footer>
</body>

</html>