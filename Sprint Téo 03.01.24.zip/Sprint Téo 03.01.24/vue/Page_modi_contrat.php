<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Ma page</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="vue/style/style.css" />
</head>

<body>
    <header>
        <h1>Ici page modif contrat</h1>
    </header>
    <nav>
      <form id="monForm1" action="forum.php" method="post">
        <p><input type="submit" value="Retour" name="Page_Directeur"><input type="submit" value="Deconnexion" name="Deconnexion"><p>
      </form>
    </nav>
    <section class="container">
        <form id="monForm2" action="forum.php" method="post">
            <?php
            foreach ($contrat as $ligne) {
                echo '<p>' . $ligne->nomContrat . '<input type="checkbox" name="supprimer[]" value="' . $ligne->nomContrat . '"/></p>';
                foreach ($motifs as $libelle) {
                    if ($libelle->libelleMotif == 'Souscription ' . $ligne->nomContrat) {
                        echo '<p><input type="text" name="Pieces[]" value="' . $libelle->listePieces . '" /><input type="hidden" name="idPieces[]" value="' . $libelle->idMotif . '"/></p>';
                        break;
                    }
                }
            }
            ?>
            <p><input type="submit" value="Modifier" name="ModifPieces" /></p>
            <p><input type="submit" value="Supprimer" name="supprimerContrat" /></p>
            <p><input type="text" value="Type de Contrat" name="Typecontrat" /><input type="text" value="Pieces demandé" name="Pieces" /></p>
            <p><input type="submit" value="Soumettre" name="ajoutcontrat" /></p>
        </form>
    </section>

    <footer class="footer">
        <!-- Contenu du pied de page ici -->
    </footer>
</body>

</html>