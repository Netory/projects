<?php
function AfficheLogin(){
    require_once('Page_login.php');
}
function AfficheDirecteur(){
    require_once('Page_Directeur.php');
}
function AfficheConseiller(){
    require_once('Page_Conseiller.php');

}
function AfficheAgent(){
    require_once('Page_Agent.php');
}
function AfficheModifEmploye($employe){
    require_once('Page_ModifAgent.php');

}
function AfficheModiContrat($contrat,$motifs){
    require_once('Page_modi_contrat.php');
}
function AfficheModiCompte($compte,$motifs){
    require_once('Page_modi_compte.php');
}

function afficherErreur($erreur){
    $contenu='<p>'. $erreur.'</p>
    <p><a href="forum.php"/> Revenir au forum </a></p>';
}
