<?php
require_once('modele/modele.php') ;
require_once('vue/vue.php') ;   

function CtlAcceuil(){
    afficherDiscussion(); // appel de la vue qui va exploiter $discussion et afficher // son contenu
}


function CtlErreur($erreur){
    afficherErreur($erreur) ;
}


