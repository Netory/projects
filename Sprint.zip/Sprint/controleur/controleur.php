<?php
require_once('modele/modele.php') ;
require_once('vue/vue.php') ;   

function CtlAcceuil(){
    $discussion=getDiscussion(); // appel du modèle qui va mettre dans la variable // $discussion un tableau de toutes les discussions de la BDD

    afficherDiscussion($discussion); // appel de la vue qui va exploiter $discussion et afficher // son contenu

}

function CtlAjouterMessage($login,$message,$mdp){

    if (!empty($login) && !empty($message) && !empty($mdp)) {
        $nom=checkuser($login,$mdp);
        if ($nom!=null){
            ajouterMessage($nom[0]->nom,$message); // appel du modèle pour insertion
        } else {throw new Exception('Login ou mdp non valide');}

        CtlAcceuil(); // appelle de la fonction précédente du contrôleur
    }
   else {
        throw new Exception("nom ou message invalide"); 
    }
}

function CtlSupprimerMessage($id){
    if (ctype_digit($id)){
    supprimerMessage($id); // appel du modèle pour suppression
    CtlAcceuil(); // appelle de la fonction du contrôleur qui affiche les discussion
     }
    else {
        throw new Exception("id message invalide");
    }
    
} 

function CtlErreur($erreur){
    afficherErreur($erreur) ;
}


