<?php
require_once('controleur/controleur.php'); // charge les méthodes du contrôleur
try {
    if (isset($_POST['conexion'])){ // si on a cliqué sur Envoyer
        $user=$_POST['login'];
        $mdp=$_POST['mdp'];
        CtlAjouterMessage($user,$msg,$mdp); // appel du contrôleur qui gère le cas postage d'un msg
    }
    elseif (isset($_POST['supprimer'])){ // si on a cliqué sur Supprimer
        $id=$_POST['idmsg'];
        CtlSupprimerMessage($id); // appel du contrôleur qui gère le cas suppression d'un msg
    }
    else CtlAcceuil(); // on vient d'arriver sur la page et on appelle le contrôleur qui gère
}


catch(Exception $e) {// une erreur est survenu dans le bloc try
     $msg = $e->getMessage() ; // on récupère son code
     CtlErreur($msg); // on appelle le contrôleur qui gère les erreurs.
}