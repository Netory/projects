<?php
    define("SERVEUR","localhost");
    define("USER","root");
    define("PASSWORD","");
    define("BDD","forumtp4");