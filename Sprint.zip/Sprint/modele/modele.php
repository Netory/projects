<?php
require_once("connect.php");
function getConnect(){
    $connexion=new PDO('mysql:host='.SERVEUR.';dbname='.BDD,USER,PASSWORD);
    $connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $connexion->query('SET NAMES UTF8');
    return $connexion;
}

function getDiscussion(){
    $connexion=getConnect(); // création d'une connexion PDO
    $requete="select * from forum limit 10" ; // Limit 10 signifie les 10 premiers
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
     $discussion=$resultat->fetchall();
    // $discussion est donc un tableau d'objet où chaque case est un objet contenant une ligne
    //entière du résultat de la requête
     $resultat->closeCursor();
    return $discussion;
}

function ajouterMessage($nom,$message){
    $connexion=getConnect(); // création d'une connexion PDO
    $requete="insert into forum values (0, '$nom', '$message')" ;
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}

function supprimerMessage($id){
    $connexion=getConnect(); // création d'une connexion PDO
    $requete="delete from forum where id=$id" ;
    $resultat=$connexion->query($requete);
    $resultat->closeCursor();
}

function checkUser($login,$mdp){
    $connexion=getConnect();
    $requete="SELECT nom from user where id='$login' and mdp='$mdp'";
    $resultat=$connexion->query($requete);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $nom=$resultat->fetchAll();
    $resultat->closeCursor();
    return $nom;
}
   