<?php
function afficherDiscussion(){
    $contenu= '';
    require_once('Page_login.php');
}


function afficherErreur($erreur){
    $contenu='<p>'. $erreur.'</p>
    <p><a href="forum.php"/> Revenir au forum </a></p>';
    require_once('vue/gabarit.php');
}
