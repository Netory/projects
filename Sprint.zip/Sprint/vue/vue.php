<?php
function afficherDiscussion($discussion){
    $contenu='<form id="monForm" action="" methode="post"><fieldset> <legend> Les message déjà postés </legend>' ;
    foreach ($discussion as $ligne){
    $contenu.= '<p><label>'.$ligne->nom.' : </label> <input type="text" value=" '.$ligne->msg.'['. $ligne->id.']"/> </p>';
    }
    $contenu.= '</fielset></form>';
    require_once('gabarit.php');
}


function afficherErreur($erreur){
    $contenu='<p>'. $erreur.'</p>
    <p><a href="forum.php"/> Revenir au forum </a></p>';
    require_once('vue/gabarit.php');
}
